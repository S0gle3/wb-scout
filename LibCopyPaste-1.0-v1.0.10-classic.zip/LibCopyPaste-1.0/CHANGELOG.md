# LibCopyPaste-1.0

## [v1.0.10](https://github.com/Oppzippy/LibCopyPaste/tree/v1.0.10) (2020-10-14)
[Full Changelog](https://github.com/Oppzippy/LibCopyPaste/compare/v1.0.9...v1.0.10) [Previous Releases](https://github.com/Oppzippy/LibCopyPaste/releases)

- Update LibCopyPaste-1.0.toc  
# LibCopyPaste-1.0

## [v1.0.8](https://github.com/Oppzippy/LibCopyPaste/tree/v1.0.8) (2019-11-12)
[Full Changelog](https://github.com/Oppzippy/LibCopyPaste/compare/v1.0.7...v1.0.8)

- Add option to auto hide frame when ctrl+c is pressed  
- Rename LICENSE  
- Fix mixed spaces and tabs  
- Update .luacheckrc  
- Update .pkgmeta  
- Bump toc  
- Remove dotfiles from .pkgmeta ignore  
- Update doc  
